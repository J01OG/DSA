/*
1.Write a program using structure to read and display the information about a student.
(name, roll no, redg no, mob no, semester, dob)
*/

#include<stdio.h>
struct student{
	int roll;
	char name[20];
	int rno;
	long int mno;
	int sem;
	struct d{
		int d;
		int m;
		int y;
	}date;
	
};
int main()
{
	int n,i;
	printf("Enter number of student: ");
	scanf("%d",&n);
	
	struct student var[n];
	
	for(i=0;i<n;i++)
	{
		printf("-----------for STUDENT %d------------------\n",i+1);
		
		printf("Enter name: ");
		scanf(" %[^\n]s",var[i].name);
		
		printf("Enter roll: ");
		scanf("%d",&var[i].roll);
		
		printf("Enter reg no: ");
		scanf("%d",&var[i].rno);
		
		printf("Enter mob no: ");
		scanf("%d",&var[i].mno);
		
		printf("ENTER DATE OF BIRTH: ");
		printf("DAY: ");
		scanf("%d",&var[i].date.d);
		printf("MONTH: ");
		scanf("%d",&var[i].date.m);
		printf("YEAR(YYYY): ");
		scanf("%d",&var[i].date.y);
		
		printf("ENTER SEM");
			scanf("%d",&var[i].sem);
		
	}
	//display
	printf("\n%-5s\t%-15s\t%-10s\t%-10s\t%-10s\t%-3s\t%-12s\n","Sr.no","NAME","RGno.","ROLLno","DoB","SEM","mobile no.");
	for(i=0;i<n;i++)
		printf("%-5d\t%-15s\t%-10d\t%-10d\t%-2d/%-2d/%-4d\t%-3d\t%-12d\n",i+1,var[i].name,var[i].rno,var[i].roll,var[i].date.d,var[i].date.m,var[i].date.y,var[i].sem,var[i].mno);
	return 0;
}
	
