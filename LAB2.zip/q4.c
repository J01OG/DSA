/*
4. WAP to read, display, add and subtract two complex numbers.
*/
#include <stdio.h>

struct complex 
{
    float real;
    float imag;
} ;


int main() 
{
    struct complex n1, n2, result_sum,result_diffrence;
    printf("For 1st complex number \n");
    printf("Enter the real then imaginary parts: ");
    scanf("%f %f", &n1.real, &n1.imag);
    
    printf("\nFor 2nd complex number \n");
    printf("Enter the real then imaginary parts: ");
    scanf("%f %f", &n2.real, &n2.imag);
    
    result_sum.real=n1.real+n2.real;
    result_sum.imag=n1.imag+n2.imag;
    
    result_diffrence.real=n1.real-n2.real;
    result_diffrence.imag=n1.imag-n2.imag;
    
    
    printf("Sum = %.1f + %.1fi", result_sum.real, result_sum.imag);
    printf("\nDIFFRENCE = %.1f + %.1fi", result_diffrence.real, result_diffrence.imag);
    
	return 0;
}
