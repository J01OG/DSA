/*
3. Write a program using structure to find out biggest number among three numbers.
*/
struct num{
	int a;
	int b;
	int c;
};

#include<stdio.h>
int main()
{
	struct num n;
	printf("Enter 3 number one by one: ");
	scanf("%d %d %d",&n.a,&n.b,&n.c);
	int max=n.a;
	if(max<n.b)
		max=n.b;
	if(max<n.c)
	 	max=n.c;
	 
	printf("GRETEST NUMBER: %d",max); 	
	 	
	return 0;
}
