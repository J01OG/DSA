/*
2. Write a program using structure to read and display the information about all the students in a class. 
Then edit the detail of the ith student and display the entire information.
*/
#include<stdio.h>
struct student{
	int roll;
	char name[20];
	int rno;
	long int mno;
	int sem;
	struct d{
		int d;
		int m;
		int y;
	}date;	
};
void display(struct student var,int i)
{
		printf("%-5d\t%-15s\t%-10d\t%-10d\t%-2d/%-2d/%-4d\t%-3d\t%-12d\n",i+1,var.name,var.rno,var.roll,var.date.d,var.date.m,var.date.y,var.sem,var.mno);	
}
int main()
{
	int n,i,c;
	printf("Enter number of student: ");
	scanf("%d",&n);
	
	struct student var[n];
	
	for(i=0;i<n;i++)
	{
		printf("-----------for STUDENT %d------------------\n",i+1);
		
		printf("Enter name: ");
		scanf(" %[^\n]s",var[i].name);
		
		printf("Enter roll: ");
		scanf("%d",&var[i].roll);
		
		printf("Enter reg no: ");
		scanf("%d",&var[i].rno);
		
		printf("Enter mob no: ");
		scanf("%d",&var[i].mno);
		
		printf("ENTER DATE OF BIRTH: ");
		printf("DAY: ");
		scanf("%d",&var[i].date.d);
		printf("MONTH: ");
		scanf("%d",&var[i].date.m);
		printf("YEAR(YYYY): ");
		scanf("%d",&var[i].date.y);
		
		printf("ENTER SEM: ");
			scanf("%d",&var[i].sem);
		
	}
	//display
	printf("\n%-5s\t%-15s\t%-10s\t%-10s\t%-10s\t%-3s\t%-12s\n","Sr.no","NAME","RGno.","ROLLno","DoB","SEM","mobile no.");
		for(i=0;i<n;i++)
			display(var[i],i);
	
	do{
		printf("want to edit the data? ");
		printf("\n1.yes");
		printf("\n2.exit");
		printf("\nENTER YOUR CHOICE(1/2):");
		scanf("%d",&c);
		switch(c)
		{
		case 1:	printf("\n%-5s\t%-15s\t%-10s\t%-10s\t%-10s\t%-3s\t%-12s\n","Sr.no","NAME","RGno.","ROLLno","DoB","SEM","mobile no.");
			for(i=0;i<n;i++)
				display(var[i],i);
		printf("Enter sr no to be edited: ");
		scanf("%d",&i);
		i=i-1;
		printf("-----------for STUDENT %d------------------\n",i+1);
		
		printf("Enter name: ");
		scanf(" %[^\n]s",var[i].name);
		
		printf("Enter roll: ");
		scanf("%d",&var[i].roll);
		
		printf("Enter reg no: ");
		scanf("%d",&var[i].rno);
		
		printf("Enter mob no: ");
		scanf("%d",&var[i].mno);
		
		printf("ENTER DATE OF BIRTH: ");
		printf("DAY: ");
		scanf("%d",&var[i].date.d);
		printf("MONTH: ");
		scanf("%d",&var[i].date.m);
		printf("YEAR(YYYY): ");
		scanf("%d",&var[i].date.y);
		
		printf("ENTER SEM: ");
			scanf("%d",&var[i].sem);
		
		printf("EDITING COMPLETE!!");
		
		printf("\nupdated list: ");					
		printf("\n%-5s\t%-15s\t%-10s\t%-10s\t%-10s\t%-3s\t%-12s\n","Sr.no","NAME","RGno.","ROLLno","DoB","SEM","mobile no.");
		for(i=0;i<n;i++)
			display(var[i],i);	
		break;	
	
	case 2: break;
	default:printf("INVALID INPUT!!");
}
	}while(c!=2);
		
	return 0;
}
	


