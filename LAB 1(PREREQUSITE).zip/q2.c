/*
Jayash prem
date:24/07/2022
question:Q2. Write a program in c to display maximum of three numbers using 2 simple if (one condition)
statement.
*/
#include<stdio.h>
int main()
{
	int a,b,c,max;
	printf("ENter both the number one by one: ");
	scanf("%d %d %d",&a,&b,&c);
	
	max=a;
	
	if(b>max)
		max=b;;
	if(c>max)
		max=c;
	
	printf("Greatest Number: %d",max);
		
	return 0;
}
