/*
Jayash prem
date:24/07/2022
question:Q6. Write a program in c to display PASCAL triangle.
*/
#include <stdio.h>
int main() {
   int n,c=1,sp,i,j;
   printf("Enter the number of rows: ");
   scanf("%d", &n);
   
   for (i=0;i<n;i++) 
   {
      for (sp=1;sp<=n-i;sp++)
         printf("  ");
      for (j=0;j<=i;j++) 
	  {
         if (j==0||i==0)
            c=1;
         else
            c=c*(i-j+1)/j;
         printf("%4d",c);
      }
      printf("\n");
   }
   return 0;
}
