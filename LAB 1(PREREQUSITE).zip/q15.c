#include<stdio.h>

void swap(int *x,int *y)
{
	int temp= *x;
	*x=*y;
	*y=temp;
}
int main()
{
	int a,b;
	printf("ENTER THE VALUE OF A AND B: ");
	scanf("%d %d",&a,&b);
	printf("VALUE BEFORE SWAP\nA:%d\tb:%d\n",a,b);
	swap(&a,&b);
	printf("VALUE AFTER SWAP\nA:%d\tb:%d\n",a,b);
	return 0;
}
