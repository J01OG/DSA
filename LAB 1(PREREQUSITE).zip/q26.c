/*
Q26. Write a menu driven program to add a data, remove data, and modify data from a structure
(name, cgpa)
Jayash prem
*/
#include<stdlib.h>
#include<stdio.h>
struct student{
	char name[20];
	float cgpa;
};

void accept(struct student *ptr,int *n)
{
	int i=0;
	while(i<*n)
	{
		printf("-----------FOR STUDENT %d-------------\n",i+1);
		printf("Enter name: ");
		scanf(" %[^\n]s",ptr->name);
		
		printf("Enter cgpa: ");
		scanf("%f",&ptr->cgpa);
		i+=1;
		ptr++;	
	}
	ptr=ptr-*n;	

}

void display(struct student *ptr,int n)
{
	int i=0;
	printf("%-5s\t%-15s\t%-4s\n","Sr.no","NAME","CGPA");
	while(i<n)
	{
		printf("%-5d\t%-15s\t%-4.2f\n",i+1,(ptr+i)->name,(ptr+i)->cgpa);	
		i+=1;
	}

}


void add(struct student *ptr,int *n)
{
	int a,i;
	printf("\nOLD LIST:\n ");
	display(ptr,*n);
	printf("\nEnter NUMBER of student detail to be added: ");
	scanf("%d",&a);
	
	
	for(i=0;i<a;i++)
	{
		printf("-------for new student %d----------\n",i+1);
		
		printf("Enter name: ");
		scanf(" %[^\n]s",(ptr+*n+i)->name);
		
		printf("Enter CGPA: ");
		scanf("%f",&(ptr+*n+i)->cgpa);
		
	}
	printf("\nUpdated list: \n");
	*n=*n+a;
	display(ptr,*n);
	

}
void del(struct student *ptr,int *n)
{
	display(ptr,*n);
	int d,i;
	printf("Enter sr no to be deleted: ");
	scanf("%d",&i);
	while(i<*n)
	{
		*(ptr+i-1)=*(ptr+i);
		i+=1;
	}
	printf("\nUpdated list: \n");
	*n=*n-1;
	display(ptr,*n);
	

}

void edit(struct student *ptr,int *n)
{
	display(ptr,*n);
	int i;
	printf("\nENter sr.no to be edited: ");
	
	scanf("%d",&i);
	
	printf("ENter new name: ");
	scanf( " %[^\n]s",(ptr+i-1)->name);
	
	printf("Enter new cgpa: ");
	scanf("%f",&(ptr+i-1)->cgpa);
	
	printf("\nupdated list:\n");
	display(ptr,*n);
}



int main()
{
	int n,c;
	printf("Enter number of student: ");
	scanf("%d",&n);
	struct student var[n];
	struct student *ptr=(struct student*)malloc((n+10)*sizeof(struct student));
	
	accept(ptr,&n);
	do
	{
		printf("\t\t\tWELCOME TO THE MENU\n");
		printf("\n1.add data");
		printf("\n2.remove data");
		printf("\n3.modify data");
		printf("\n4.EXIT");
		printf("\nEnter your choice(1/2/3/4): ");
		
		scanf("%d",&c);
		
		switch(c)
		{
			case 1:add(ptr,&n);break;
			case 2:del(ptr,&n);break;
			case 3:edit(ptr,&n);break;
			case 4:break;
			default:printf("\nINVALID INPUT GO AGIAN!\n");
		}
	}
	while(c!=4);
	
	return 0;
}

