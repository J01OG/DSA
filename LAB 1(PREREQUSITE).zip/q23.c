#include<stdio.h>
#include<string.h>
struct student {
	char name[20];
	float cgpa;
};

void display(char name[20],struct student data[20],int n)
{
	int present=0,i;
	for(i=0;i<n;i++)
		if(strcmp(name,data[i].name)==0)
			{
				printf("Name: %s\nCGPA: %0.2f",data[i].name,data[i].cgpa);
				present=1;
			}
	if(present==0)
		printf("%s not present in the list",name);
}

int main()
{
	int n,i;
	char name[20];
	printf("Enter number of studet(n) : ");
	scanf("%d",&n);
	
	struct student data[n];
	
	printf("\nEnter the data of student one by one\n");
	for(i=0;i<n;i++)
	{
		printf("-----------STUDENT %d--------------\n",i+1);
		printf("Enter name: ");
		scanf(" %s",data[i].name);
		
		printf("enter CGPA: ");
		scanf("%f",&data[i].cgpa);
		
	}
	
	printf("Enter name of student: ");
	scanf("%s",name);
	
	display(name,data,n);		
	
	return 0;
}
