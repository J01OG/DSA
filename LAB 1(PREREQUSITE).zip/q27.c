/*
Q27. Write a program in c to add money to the account (account no, name, balance), or withdraw
money from the account through a menu driven program.

*/
struct account{
	long int An;
	char name[15];
	float balance;
};

#include<stdio.h>
int main()
{
	struct account d1;
		printf("Enter acoount holder name: ");
		scanf("%[^\n]s",d1.name);
		
		printf("Enter account number: ");
		scanf("%d",&d1.An);
		int c;
		d1.balance=0.0;
		float temp;
	do{
		printf("------------------MENU-------------------\n");
		printf("\n1.account inquiry");
		printf("\n2.DEPOSITE");
		printf("\n3.WITHDRAW");
		printf("\n4.EXIT");
		printf("\nEnter choice(1/2/3/4): ");
		
		
		scanf("%d",&c);
		
		switch(c)
		{
			case 1:
				printf("\nacno: %d\taccount holder: %s \t BALANCE: %0.2f\n",d1.An,d1.name,d1.balance);break;
			case 2:
				printf("Enter amount to be Deposite: ");
				scanf("%f",&temp);
				d1.balance=d1.balance+temp;
				temp=0;
				break;
			case 3:
				printf("Enter amount to be withdraw: ");
				scanf("%f",&temp);
				if(temp<=d1.balance&&temp>0)
					d1.balance=d1.balance-temp;
				else
					printf("Not enough balance or invalid entry!");
				temp=0;
				break;
			case 4:break;
			default:printf("INVALID ENTRY!");break;
		}
		
		
	}while(c!=4);	
		
	
	return 0;
}
