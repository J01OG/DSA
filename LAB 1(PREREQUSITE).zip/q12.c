

#include<stdio.h>
#include<string.h>
int main()
{
	char str[100],str1[100];
	int k,ch,b=0,j;
	
	printf("ENTER THE STRING:");
	scanf(" %[^\n]s",str);
	
	printf("ENTER THE SUBSTRING: ");
	scanf(" %[^\n]s",str1);
	
	int len=strlen(str),len1=strlen(str1),i=0;
	
	while(str[i]!='\0')
	{
		b=0;
		if(str[i]==str1[0])
			{
				k=0,ch=0,b=0;
				for(j=i;j<i+len1;j++)
					if(str1[k++]==str[j])
						ch++;
				if(ch==len1)
					b=1;
			}
		if(b==1)
			{
				printf("%s is present in the main string",str1);
				break;
			}
		i=i+1;
	}
		if(b==0)
			printf(" %s is not present in the string",str1);
		
	return 0;
}
