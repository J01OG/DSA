/*
Jayash prem
date:24/07/2022
question:Q4. Write a program in c to check a number is ARMSTRONG number or not.
*/
#include<stdio.h>
int main()
{
	int n;
	printf("Enter the number: ");
		scanf("%d",&n);
	int temp=n,rem,c;	
		while(n!=0)
		{
			rem=n%10;
			c+=rem*rem*rem;
			n=n/10;
		}
		
	if(c==temp)
		printf("%d is an armstrong number",temp);
	else
		printf("%d is not an armstrong number",temp);	
		
	return 0;
}
