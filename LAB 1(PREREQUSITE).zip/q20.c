#include<stdio.h>

struct one{
	int a;
	int b;
};
struct two{
	int a;
	int b;
	int c;
	int d;
};
int main()
{
	struct one a1,a2;
	struct two b;
	
	printf("ENTER THE VALUE OF A & B for STRUCT(a1): ");
	scanf("%d %d",&a1.a,&a1.b);
	
	printf("ENTER THE VALUE OF A & B for STRUCT(a2): ");
	scanf("%d %d",&a2.a,&a2.b);
		
	b.a=a1.a;
	b.b=a1.b;
	b.c=a2.a;
	b.d=a2.b;
	
	printf("\nJOINED STRUCTURE(b):\nA:%d\tB:%d\tC:%d\tD:%d",b.a,b.b,b.c,b.d);
	
}
