
/*
Jayash prem
date:24/07/2022
question:Q7. Write a program in c to display how many digits of a number without loop and if statement.
*/
#include<string.h >
#include<stdio.h>
int main()
{
	char ch[10];
	printf("Enter the number: ");
	scanf("%s",ch);

	
	printf("number of digit: %d",strlen(ch));
	
	return 0;
}
