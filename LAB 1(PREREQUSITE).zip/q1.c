/*
Jayash prem
date:24/07/2022
question:Q1. Write a program in c to display maximum of two numbers without if statement.
*/
#include<stdio.h>
int main()
{
	int a,b;
	printf("ENter both the number one by one: ");
	scanf("%d %d",&a,&b);
	
	printf("Max number : %d",a>b?a:b);
	
	
	return 0;
}
