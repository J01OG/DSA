/*
Jayash prem
date:24/07/2022
question:Q8. Write a program in c to reverse an array.
*/
#include<stdio.h>
int main()
{
	int n,i,temp;
	printf("Enter number of element in the array: ");
	scanf("%d",&n);
	
	int arr[n];
	
	printf("Enter array element one by one: ");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	
	printf("\nEntered array : ");
		for(i=0;i<n;i++)
			printf("%d ",arr[i]);
	
	for(i=0;i<n/2;i++)
		{
			temp=arr[i];
			arr[i]=arr[n-i-1];
			arr[n-i-1]=temp;
		}
		
	printf("\nReversed array: ");
		for(i=0;i<n;i++)
			printf("%d ",arr[i]);
	
	return 0;
}
