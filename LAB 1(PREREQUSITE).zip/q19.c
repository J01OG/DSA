struct student{
	char name[15];
	float cgpa;
};

#include<stdio.h>
int main()
{
	int n,i,j;
	printf("Enter no of student: ");
	scanf("%d",&n);
	struct student data[n];
	printf("ENter the data one by one: ");
	for(i=0;i<n;i++)
	{
		printf("\n------------STUDENT %d----------------\n",i+1);
		printf("ENter name: ");
		scanf(" %s",data[i].name);
		printf("ENTER CGPA: ");
		scanf("%f",&data[i].cgpa);
	}
	printf("STUDENT LIST:\n");
	
	printf("%-20s\t%-4s\n","NAME","CGPA");
	for(i=0;i<n;i++)
		printf("%-20s\t%-0.2f\n",data[i].name,data[i].cgpa);
		
	struct student temp;
		
	for(i=0;i<n;i++)
		{
			for(j=0;j<n-i;j++)
			{
				if(data[j].cgpa<data[j+1].cgpa)
				{
					temp=data[j];
					data[j]=data[j+1];
					data[j+1]=temp;
				}
			}
			}	
	printf("\n\nSORTED LIST:\n\n");
	printf("%-20s\t%-4s\n","NAME","CGPA");
	for(i=0;i<n;i++)
		printf("%-20s\t%-0.2f\n",data[i].name,data[i].cgpa);
		

	return 0;
}
