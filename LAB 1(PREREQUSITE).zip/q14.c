/*
Jayash prem
Q14. Write a program in c to display unique characters from a string. (Remove duplicate).
*/
#include<string.h>
#include<stdio.h>
int main()
{
	int i,j,c;
	char str[30];
	printf("enter the string: ");
	scanf(" %[^\n]s",str);
	printf("Unique characters in the string:");
	for(i=0;i<strlen(str);i++)
	{
		c=0;
		for(j=0;j<strlen(str);j++)
			if(str[i]==str[j])
				c++;
			if(c==1)
				printf(" \"%c\" ",str[i]);
	}
	
	return 0;
}
