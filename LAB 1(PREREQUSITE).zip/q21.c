#include<stdio.h>

struct student{
	char name[15];
	float cgpa;
};

int main()
{
	int n,i,j;
	printf("Enter no of student: ");
	scanf("%d",&n);
	struct student data[n];
	printf("ENter the data one by one: ");
	for(i=0;i<n;i++)
	{
		printf("\n------------STUDENT %d----------------\n",i+1);
		printf("ENter name: ");
		scanf(" %s",data[i].name);
		printf("ENTER CGPA: ");
		scanf("%f",&data[i].cgpa);
	}
	printf("STUDENT LIST:\n");
	
	printf("%-20s\t%-4s\n","NAME","CGPA");
	for(i=0;i<n;i++)
		printf("%-20s\t%-0.2f\n",data[i].name,data[i].cgpa);
		
	printf("STUDENT HAVE CGPA MORE THAN 9.8:\n");
	
	printf("%-20s\t%-4s\n","NAME","CGPA");
	for(i=0;i<n;i++)
		if(data[i].cgpa>=9.8)
			printf("%-20s\t%-0.2f\n",data[i].name,data[i].cgpa);
			
	
	return 0;
}
