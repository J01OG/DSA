struct stu
{
	char name[10];
		struct b{
		int d;
		int m;
		int y;
	}date;
};
#include<stdio.h>
int main()
{
	struct stu data;
	printf("Enter name of the student: ");
	scanf(" %[^\n]s",data.name);
	printf("ENter date of birth: dd/mm/yyyy formate : ");
	scanf("%d %d %d",&data.date.d,&data.date.m,&data.date.y);
	
	printf("\nName: %s\nDob: %d/%d/%d",data.name,data.date.d,data.date.m,data.date.y);
	return 0;
}
