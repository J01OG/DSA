#include<stdio.h>

struct student{
	char name[20];
	int age;
	float cgpa;
	char roll[10];
};

void display(struct student data)
{
	printf("%-10s\t%-15s\t%-3s\t%-4s\n","ROLL","NAME","AGE","CGPA");
	printf("%-10s\t%-15s\t%-3d\t%-0.2f\n",data.roll,data.name,data.age,data.cgpa);
}

int main()
{
	struct student data;
	printf("Enter the detail of the student\n");
	
	printf("ENter name: ");
	scanf(" %s",data.name);
	
	printf("Enter roll: ");
	scanf(" %s",data.roll);
	
	printf("enter age: ");
	scanf("%d",&data.age);
	
	printf("Enter cgpa of %s: ",data.name);
	scanf("%f",&data.cgpa);
	
	display(data);
	
	return 0;
}
