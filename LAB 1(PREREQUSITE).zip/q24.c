#include<string.h>
#include<stdio.h>
struct student{
	char name[20];
	float cgpa;
};


void display(struct student temp)
{
	printf("NAME: %s\tCGPA: %0.2f\n",temp.name,temp.cgpa);
}

int main()
{
	int n,l,i,b,k,ch,j;
	printf("Enter number of studet(n) : ");
	scanf("%d",&n);
	
	struct student var[n];
	
	printf("\nEnter the data of student one by one\n");
	for(i=0;i<n;i++)
	{
		printf("-----------STUDENT %d--------------\n",i+1);
		printf("Enter name: ");
		scanf(" %[^\n]s",var[i].name);
		
		printf("enter CGPA: ");
		scanf("%f",&var[i].cgpa);
		
	}
	char str1[6]="KUMAR";
	int len1=strlen(str1);
	for(l=0;l<n;l++)
	{
		i=0;
	while(var[l].name[i]!='\0')
		{
		b=0;
		if((var[l].name[i])==(str1[0]))
			{
				k=0,ch=0,b=0;
				for(j=i;j<i+len1;j++)
					if(str1[k++]==var[l].name[j])
						ch++;
				if(ch==len1)
					b=1;
			}
		if(b==1)
			{
				display(var[l]);
			}
		i=i+1;
		}
	}

	return 0;
}
