/*
Q30. Write a program in c to display rank particular of student from the structure (roll, name,
m1,m2,m3, grade, rank).
*/
struct student{
	int roll;
	char name[20];
	int m1;
	int m2;
	int m3;
	char grade;
	int rank;
};

#include<stdio.h>
int main()
{
	int n,i,j,sum1,sum2,rank;
	printf("enter number of studet(n): ");
	scanf("%d",&n);
	struct student list[n];
	
	for(i=0;i<n;i++)
	{
		printf("==========STUDENT %d===========\n",i+1);
		printf("Enter name: ");
		scanf("%s",list[i].name);
		
		printf("Enter roll:  ");
		scanf("%d",&list[i].roll);
		
		printf("Enter marks 1: ");
		scanf("%d",&list[i].m1);
		
		printf("marks 2: ");
		scanf("%d",&list[i].m2);
		
		printf("marks 3: ");
		scanf("%d",&list[i].m3);
	}
	
	for(i=0;i<n;i++)
	{
		sum1=list[i].m1+list[i].m2+list[i].m3;
		sum2=0;rank=1;
		for(j=0;j<n;j++)
			{
				sum2=list[j].m1+list[j].m2+list[j].m3;
				if(sum1<sum2)
					rank++;
			}
		
		list[i].rank=rank;
		
		sum1=sum1/3;
		
		if(sum1<40)
			list[i].grade='F';
		if(sum1>=40&&sum1<50)
			list[i].grade='D';
		if(sum1>=50&&sum1<60)
			list[i].grade='C';
		if(sum1>=60&&sum1<70)
			list[i].grade='B';
		if(sum1>=70&&sum1<80)
			list[i].grade='A';
		if(sum1>=80&&sum1<90)
			list[i].grade='E';
		if(sum1>=90&&sum1<101)
			list[i].grade='O';
	}
	 
	//display
	printf("%-4s\t%-15s\t%-10s\t%-7s\t%-7s\t%-7s\t%-5s\n","RANK","NAME","ROLL","MARKS 1","MARKS 2","MARKS 3","GRADE");
	
	for(i=0;i<n;i++)
		printf("%-4d\t%-15s\t%-10d\t%-7d\t%-7d\t%-7d\t%c\n",list[i].rank,list[i].name,list[i].roll,list[i].m1,list[i].m2,list[i].m3,list[i].grade);

	return 0;
}
	
	
