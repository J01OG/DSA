/*
Jayash prem
.Q17. Write a program in c to return maximum when the function called first time and minimum when
the function called second time.
*/
#include<stdio.h>
int max_min(int a,int b,int c,int *call)
{
	int max=a;
	int min=a;
	if(max<b)
		max=b;
	if(max<c)
		max=c;
	if(min>a)
		min=a;
	if(min>c)
		min=c;
		if(*call==1)
			{
				*call=2;
				return max;
			}
		else
			{
				*call=1;
				return min;
			}
}
int main()
{
	int a,b,c,call=1;
	printf("Enter the value of a,b,c: ");
	scanf("%d %d %d",&a,&b,&c);

	printf("call 1 ans: %d ",max_min(a,b,c,&call));
	printf("\ncall 2 ans: %d",max_min(a,b,c,&call));

	return 0;
}
