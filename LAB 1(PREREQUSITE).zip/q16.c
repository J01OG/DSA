/*
Jayash prem
Q16. Write a program in c to return maximum and minimum out of three numbers from one function.
*/
#include<stdio.h>
void max_min(int a,int b,int c,int *max,int *min)
{
	*max=a;
	*min=a;
	if(*max<b)
		*max=b;
	if(*max<c)
		*max=c;
	if(*min>b)
		*min=b;
	if(*min>c)
		*min=c;
		
}
int main()
{
	int a,b,c,max,min;
	printf("Enter the value of a,b,c: ");
	scanf("%d %d %d",&a,&b,&c);
	max_min(a,b,c,&max,&min);
	printf("GRETEST: %d",max);
	printf("\nSMALLEST: %d",min);
	return 0;
}
