/*
Jayash prem
date:24/07/2022
question:Q5. Write a program in c to check a number is twisted prime or not.
*/
#include<stdio.h>
int main()
{
	int n,i;
	printf("Enter the number: ");
		scanf("%d",&n);
	
	int temp=n,rem,rev=0;	
	
		while(n!=0)
		{
			rem=n%10;
			rev=rem+rev*10;
			n=n/10;
		}
	
	int flag=0;	
		
	for(i=2;i<=rev-1;i++)
		if(rev%i==0)
			flag=1;
	for(i=2;i<=temp-1;i++)
		if(temp%i==0)
			flag=1;
		
	if(flag)
		printf("%d is not an twisted prime number",temp);
	else
		printf("%d is a twisted prime number",temp);
	return 0;
}
