/*
Q29. Write a program in c to display common information of two same type of structure.
*/
struct student{
	char name[20];
	float cgpa;
};
#include<string.h>
#include<stdio.h>
int main()
{
	int i,n1,n2,j;
	printf("ENTER number of student in list 1(n1): ");
	scanf("%d",&n1);
	printf("ENTER number of studetn in list 2(n2): ");
	scanf("%d",&n2);
	
	struct student l1[n1];
	struct student l2[n2];
	
	printf("for list 1:\n");
	for(i=0;i<n1;i++)
	{
		printf("-------Student %d------------",i+1);
		printf("\nEnter name: ");
		scanf(" %[^\n]s",l1[i].name);
		printf("Enter cgpa: ");
		scanf("%f",&l1[i].cgpa);
	}

	printf("\nfor list 2:\n");
	
	for(i=0;i<n2;i++)
	{
		printf("-------Student %d------------",i+1);
		printf("\nEnter name: ");
		scanf(" %[^\n]s",l2[i].name);
		printf("Enter cgpa: ");
		scanf("%f",&l2[i].cgpa);
	}	
	printf("common information:\n");
	
	printf("%-20s\t%-4s\n","NAME","CGPA");
	
	for(i=0;i<n1;i++)
	{
		for(j=0;j<n2;j++)
		{
			if((l1[i].cgpa==l2[j].cgpa)&&(strcmp(l1[i].name,l2[j].name)==0))
				printf("%-20s\t%-4.2f\n",l1[i].name,l1[i].cgpa);
		}
	}	
	
	
	return 0;
}
