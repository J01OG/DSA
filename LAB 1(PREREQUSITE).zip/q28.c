/*
Q28. Write a program in c to display cgpa from the structure (name, cgpa), and the name can be
determine from the structure (name, roll), the roll number is searching key
*/
struct stud1{
	char name[15];
	float cgpa;
};

struct stud2{
	char name[15];
	int roll;
};
#include<stdio.h>
#include<string.h>
int main()
{
	int i,n,key;
	char namekey[15];
	printf("Enter number of student: ");
	scanf("%d",&n);
	
	struct stud1 data[n];
	struct stud2 data2[n];
	
	for(i=0;i<n;i++)
	{
		printf("----------STUDENT %d----------\n",i+1);
		printf("Enter name: ");
		scanf(" %[^\n]s",data[i].name);
		
		strcpy(data2[i].name,data[i].name);
		
		printf("ENTER ROLL: ");
		scanf("%d",&data2[i].roll);
		
		printf("Enter CGPA: ");
		scanf("%f",&data[i].cgpa);
		
	}
	
	printf("Enter roll number to be searched: ");
	scanf("%d",&key);
	
	for(i=0;i<n;i++)
	{
		if(key==data2[i].roll)
		{
			strcpy(namekey,data2[i].name);
			break;
		}
	}
	
	for(i=0;i<n;i++)
	{
		if(strcmp(namekey,data[i].name)==0)
			{
				printf("NAME: %s\t CGPA: %0.2f",data[i].name,data[i].cgpa);
				break;
			}
	}
	

	return 0;
}
