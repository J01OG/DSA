#include<stdio.h>
#include<string.h>

struct student{
	char name[20];
	float cgpa;
};
void display(struct student temp)
{
	printf("NAME: %-15s\tCGPA: %-4.2f\n",temp.name,temp.cgpa);
}

int main()
{
	int n,i,len,j,ov=0,ev=0;
	printf("Enter number of student: ");
	scanf("%d",&n);
	
	struct student var[n];
	
	for(i=0;i<n;i++)
	{
		printf("-----------for STUDENT %d------------------\n",i+1);
		
		printf("Enter name: ");
		scanf(" %[^\n]s",var[i].name);
		
		printf("Enter CGPA: ");
		scanf("%f",&var[i].cgpa);
		
	}
	
	for(i=0;i<n;i++)
	{
		len=strlen(var[i].name);
		for(j=0;j<len;j++)
		{
			if((var[i].name[j])=='a'||(var[i].name[j])=='i'||(var[i].name[j])=='o'||(var[i].name[j])=='u')
				ov++;
			if((var[i].name[j])=='e')
				ev++;
		}
		if(ev>0&&ov==0)
			display(var[i]);
		ev=0;
		ov=0;
	}
	
	return 0;
}
