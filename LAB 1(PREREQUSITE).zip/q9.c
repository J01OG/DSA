/*
Jayash prem
date:24/07/2022
question:Q9. Write a program in c to implement sliding window. Ex. (1 2 3 4 5) will be ( 2 1 4 3 5).
*/
#include<stdio.h>
int main()
{
	int n,i,tempn,temp;
	printf("Enter number of element in the array: ");
	scanf("%d",&n);
	
	int arr[n];
	
	printf("Enter array element one by one: ");
		for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	
	printf("\nEntered array : ");
		for(i=0;i<n;i++)
			printf("%d ",arr[i]);
	tempn=n;
	if(n%2!=0)
		tempn=n-1;		

	for(i=0;i<tempn;i+=2)
		{
		temp=arr[i];
		arr[i]=arr[i+1];
		arr[i+1]=temp;
		}
	
	printf("\nAfter implemnting sliding window: ");
	for(i=0;i<n;i++)
		printf(" %d",arr[i]);	
		
	return 0;
	
	}
