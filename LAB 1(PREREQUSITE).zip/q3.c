/*
Jayash prem
date:24/07/2022
question:Q3. Write a program in c to display first 10 Fibonacci numbers.
*/
#include<stdio.h>
int main()
{
	int a=-1,b=1,c=a+b;
	int d=0;
	printf("first 10 number in fibonaci series: ");
		while(d<10)
		{
			printf("%d ",c);
			a=b;b=c;c=a+b;d=d+1;
		}
		
	return 0;
}
